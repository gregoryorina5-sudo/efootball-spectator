# eFootball Spectator — full APK-buildable project

This package contains a complete Flutter Android project plus the Node/WebSocket backend.

## What it does
- Create a private match room
- Join as Player A or spectator
- Live score and match clock
- Goal, yellow card, red card and substitution events
- Full-time status
- Live updates over WebSocket

## Important
This is a companion app. It does **not** connect to or scrape KONAMI/eFootball private servers. Match events are sent through this app by the player/operator.

## Build the APK
From the `android_app` folder on a machine with Flutter installed:

```bash
flutter pub get
flutter build apk --release
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Cloud build without a local Flutter installation
The repository includes `.github/workflows/build-apk.yml`. Push the project to GitHub, then run the workflow from the Actions tab. The generated APK is uploaded as a workflow artifact.

## Backend
```bash
cd backend
npm install
npm start
```

The default backend port is 8080.

### Phone testing
The Flutter app currently uses `ws://10.0.2.2:8080` for an Android emulator. For a physical phone, change the server URL in `lib/main.dart` to the computer's LAN address, e.g. `ws://192.168.1.20:8080`.

For internet play between phones on different networks, deploy the backend to a public HTTPS/WSS-capable host and change the app URL to the resulting `wss://...` address.
