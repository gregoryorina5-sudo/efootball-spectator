import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

void main() => runApp(const SpectatorApp());

class SpectatorApp extends StatelessWidget {
  const SpectatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'eFootball Spectator',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final roomController = TextEditingController();
  final nameController = TextEditingController(text: 'Player A');

  // For a physical phone, replace 10.0.2.2 with your computer's LAN IP.
  static const serverUrl = 'ws://10.0.2.2:8080';

  WebSocketChannel? channel;
  Map<String, dynamic> state = {};
  String role = 'spectator';
  String? error;

  void connect(String action) {
    channel?.sink.close();
    setState(() => error = null);

    final ch = WebSocketChannel.connect(Uri.parse(serverUrl));
    channel = ch;

    ch.stream.listen((data) {
      final msg = jsonDecode(data);
      if (!mounted) return;
      if (msg['type'] == 'state') {
        setState(() => state = Map<String, dynamic>.from(msg));
      } else if (msg['type'] == 'error') {
        setState(() => error = msg['message']?.toString());
      }
    }, onError: (e) {
      if (mounted) setState(() => error = 'Connection failed: $e');
    });

    if (action == 'create') {
      role = 'playerA';
      ch.sink.add(jsonEncode({'type': 'create'}));
    } else {
      role = 'spectator';
      ch.sink.add(jsonEncode({
        'type': 'join',
        'room': roomController.text.trim().toUpperCase(),
        'role': 'spectator'
      }));
    }
  }

  void send(Map<String, dynamic> msg) {
    channel?.sink.add(jsonEncode(msg));
  }

  @override
  void dispose() {
    roomController.dispose();
    nameController.dispose();
    channel?.sink.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final score = Map<String, dynamic>.from(state['score'] ?? {'a': 0, 'b': 0});
    final events = List<dynamic>.from(state['events'] ?? []);
    final room = state['room']?.toString() ?? '—';
    final status = state['status']?.toString() ?? 'waiting';
    final clock = state['clock'] ?? 0;
    final mm = (clock ~/ 60).toString().padLeft(2, '0');
    final ss = (clock % 60).toString().padLeft(2, '0');

    return Scaffold(
      appBar: AppBar(title: const Text('⚽ eFootball Spectator')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: roomController,
            decoration: const InputDecoration(
              labelText: 'Room code',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: FilledButton(
                onPressed: () => connect('join'),
                child: const Text('Join as spectator'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                onPressed: () => connect('create'),
                child: const Text('Create room'),
              ),
            ),
          ]),
          if (error != null) ...[
            const SizedBox(height: 12),
            Text(error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(children: [
                Text('ROOM $room', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(status.toUpperCase()),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Column(children: [
                      const Text('PLAYER A'),
                      Text('${score['a'] ?? 0}',
                          style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold))
                    ]),
                    const Text('-', style: TextStyle(fontSize: 30)),
                    Column(children: [
                      const Text('PLAYER B'),
                      Text('${score['b'] ?? 0}',
                          style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold))
                    ]),
                  ],
                ),
                Text('$mm:$ss', style: const TextStyle(fontSize: 22)),
              ]),
            ),
          ),
          if (role == 'playerA') ...[
            const SizedBox(height: 12),
            const Text('Player A controls',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton(onPressed: () => send({'type': 'start'}), child: const Text('▶ Start')),
              OutlinedButton(onPressed: () => send({'type': 'pause'}), child: const Text('⏸ Pause')),
              FilledButton(onPressed: () => send({'type': 'event', 'kind': 'goal', 'side': 'a'}), child: const Text('⚽ Goal A')),
              OutlinedButton(onPressed: () => send({'type': 'event', 'kind': 'goal', 'side': 'b'}), child: const Text('⚽ Goal B')),
              OutlinedButton(onPressed: () => send({'type': 'event', 'kind': 'yellow', 'side': 'a'}), child: const Text('🟨 A')),
              OutlinedButton(onPressed: () => send({'type': 'event', 'kind': 'sub', 'side': 'a'}), child: const Text('🔄 A')),
              FilledButton(onPressed: () => send({'type': 'finish'}), child: const Text('🏁 Full time')),
            ]),
          ],
          const SizedBox(height: 20),
          const Text('🔴 LIVE EVENTS',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (events.isEmpty)
            const Text('No events yet.')
          else
            ...events.reversed.map((e) => ListTile(
                  leading: Text(e['icon']?.toString() ?? '•',
                      style: const TextStyle(fontSize: 24)),
                  title: Text(e['text']?.toString() ?? ''),
                  subtitle: Text(e['clock']?.toString() ?? ''),
                )),
        ],
      ),
    );
  }
}
