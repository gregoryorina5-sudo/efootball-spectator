import { WebSocketServer } from "ws";
import crypto from "node:crypto";

const PORT = Number(process.env.PORT || 8080);
const rooms = new Map();

function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  do {
    code = Array.from({ length: 6 }, () =>
      chars[crypto.randomInt(chars.length)]
    ).join("");
  } while (rooms.has(code));
  return code;
}

function roomSnapshot(room) {
  return {
    type: "state",
    room: room.code,
    status: room.status,
    clock: room.clock,
    score: { a: room.score.a, b: room.score.b },
    players: room.players,
    spectators: room.spectators,
    events: room.events
  };
}

function broadcast(room) {
  const message = JSON.stringify(roomSnapshot(room));
  for (const client of room.clients) {
    if (client.readyState === 1) client.send(message);
  }
}

function addEvent(room, icon, text) {
  room.events.push({
    id: crypto.randomUUID(),
    icon,
    text,
    clock: room.clock
  });
  if (room.events.length > 100) room.events.shift();
}

function getRoom(code) {
  return rooms.get(String(code || "").trim().toUpperCase());
}

const wss = new WebSocketServer({ host: "0.0.0.0", port: PORT });

wss.on("connection", (ws) => {
  ws.room = null;
  ws.role = null;

  ws.on("message", (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      ws.send(JSON.stringify({ type: "error", message: "Invalid JSON" }));
      return;
    }

    if (msg.type === "create") {
      const code = makeCode();
      const room = {
        code,
        status: "waiting",
        clock: 0,
        score: { a: 0, b: 0 },
        players: { a: "Player A", b: "Player B" },
        spectators: 0,
        events: [],
        clients: new Set(),
        timer: null
      };
      rooms.set(code, room);
      ws.room = room;
      ws.role = "playerA";
      room.clients.add(ws);
      broadcast(room);
      return;
    }

    if (msg.type === "join") {
      const room = getRoom(msg.room);
      if (!room) {
        ws.send(JSON.stringify({ type: "error", message: "Room not found" }));
        return;
      }

      const requestedRole = msg.role || "spectator";
      if (requestedRole === "playerA" || requestedRole === "playerB") {
        const occupied = [...room.clients].some(c => c.role === requestedRole);
        if (occupied) {
          ws.send(JSON.stringify({ type: "error", message: "That player slot is occupied" }));
          return;
        }
      }

      ws.room = room;
      ws.role = requestedRole;
      room.clients.add(ws);
      if (requestedRole === "spectator") room.spectators++;
      broadcast(room);
      return;
    }

    const room = ws.room;
    if (!room) {
      ws.send(JSON.stringify({ type: "error", message: "Join or create a room first" }));
      return;
    }

    if (msg.type === "start") {
      if (ws.role !== "playerA" && ws.role !== "playerB") return;
      room.status = "live";
      if (!room.timer) {
        room.timer = setInterval(() => {
          if (room.status === "live") {
            room.clock++;
            broadcast(room);
          }
        }, 1000);
      }
      broadcast(room);
      return;
    }

    if (msg.type === "pause") {
      if (ws.role !== "playerA" && ws.role !== "playerB") return;
      room.status = "paused";
      broadcast(room);
      return;
    }

    if (msg.type === "finish") {
      if (ws.role !== "playerA" && ws.role !== "playerB") return;
      room.status = "finished";
      addEvent(room, "🏁", `Full time — ${room.score.a} : ${room.score.b}`);
      broadcast(room);
      return;
    }

    if (msg.type === "event") {
      if (ws.role !== "playerA" && ws.role !== "playerB") return;

      const side = msg.side === "b" ? "b" : "a";
      const kind = String(msg.kind || "");

      const allowed = {
        goal: ["⚽", "Goal"],
        yellow: ["🟨", "Yellow card"],
        red: ["🟥", "Red card"],
        sub: ["🔄", "Substitution"]
      };

      if (!allowed[kind]) return;

      if (kind === "goal") room.score[side]++;
      const [icon, label] = allowed[kind];
      const playerName = side === "a" ? room.players.a : room.players.b;
      addEvent(room, icon, `${label} — ${playerName}`);
      broadcast(room);
    }
  });

  ws.on("close", () => {
    const room = ws.room;
    if (!room) return;

    room.clients.delete(ws);
    if (ws.role === "spectator") room.spectators = Math.max(0, room.spectators - 1);

    if (room.clients.size === 0) {
      if (room.timer) clearInterval(room.timer);
      rooms.delete(room.code);
    } else {
      broadcast(room);
    }
  });
});

console.log(`eFootball Spectator backend listening on ws://0.0.0.0:${PORT}`);
